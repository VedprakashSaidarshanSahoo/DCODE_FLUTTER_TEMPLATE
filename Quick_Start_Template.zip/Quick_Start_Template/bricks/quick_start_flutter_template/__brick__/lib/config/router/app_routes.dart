class AppRoutes {
  static const String home = '/';
  static const String loading = '/loading';
  static const String login = '/login';
  static const String counter = '/counter';
}
