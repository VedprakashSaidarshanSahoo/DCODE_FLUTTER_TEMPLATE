class ApiEndpoints {
  static const String login = "/auth/login";
  static const String getTodos = "/todos";
  static const String createTodo = "/todos/create";
}
