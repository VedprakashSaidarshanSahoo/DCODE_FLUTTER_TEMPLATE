enum AppThemeType {
  light,
  dark,
  lightColorful,
  darkColorful,
  neonDark,
  pastelLight,
}
