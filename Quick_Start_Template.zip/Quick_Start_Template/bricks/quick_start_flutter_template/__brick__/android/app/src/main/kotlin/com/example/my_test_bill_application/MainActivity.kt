package com.example.my_test_bill_application

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
